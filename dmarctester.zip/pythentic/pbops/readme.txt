
'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''


squall.py contains the python methods for creating, updating
and reading sqlite3 databases.

This directory contains databases for: dmarc.db, pgp.db
And database schemata for each of these in: dmarc_schema.sql, pgp_schema.sql
Metadata is populated from: dmarcdb.conf, pgpdb.conf
Auto test commands are found in: testfile.

python squall.py<enter>  returns the list of commands.

python squall.py autotest testfile<enter>  runs the auto testfile.

Individual commands are of the general form of:
python squall.py getresult dmarc.db<enter>

Read testfile for a comprehensive set of commands.

Intended use is to import squall as a library into your python script
and call methods with the general scheme of:
squall.putresult(dbname, dbschema, argdict)

#########################################################################
squall.py methods are as follows:

def create_db(dbname, dbschema):
def update_db(dbname, dbschema, squill, argtuple):
def update_safe(dbname, dbschema, squill, argtuple):
def extract_db(dbname, squill):
def extract_all(dbname, squill):
def putmeta(dbname, dbschema, metadata):
def putadder(dbname, dbschema, argtuple):
def getmeta(dbname):
def getadder(dbname):
def putresult(dbname, dbschema, argdict):
def unpackrec(adict):
def buildrec():
def getresult(dbname):
def setreported(dbname, dbschema, id):
def printtable(dbname, atable):
def printadders(dbname):
def printresults(dbname):
def dotests(testfile):
def docommands(sysargv):
#########################################################################


