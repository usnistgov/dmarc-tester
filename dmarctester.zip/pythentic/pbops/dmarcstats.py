import sys, os, squall

'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''

def printsorted(adict):
  for key, value in sorted(adict.iteritems(), key=lambda (k, v): (v, k), reverse=True):
    print "%s = %d" % (key, value)


def accumulate(thedict, akey):
  if akey != None and not isinstance(akey, int): lowkey = akey.lower()
  else: lowkey = akey
  if lowkey in thedict: thedict[lowkey] += 1
  else: thedict[lowkey] = 1

  return thedict


def sumup(thedict):
  thetot = 0
  for key in thedict:
    thetot += thedict[key]
  return thetot


def printtld(adict):
  bagup = {}
  for key in adict:
    bag = key.split('.')
    bagup = accumulate(bagup, bag[-1])

  printsorted(bagup)
  print "%d unique tlds." % (len(bagup))


def spiffsort(dbrex):
  sprex = []

  for reck in alldbrex:
    if reck[11] == "":
      sprex.append("non")
    elif reck[11] == None:
      continue
    elif reck[11].find('#') > 0:
      sparts = reck[11].split('#')
      for spart in sparts:
        sprex.append(spart)
    else:
      sprex.append(reck[11])

  sprex.sort(lambda x,y:  cmp(len(x), len(y)))
  for spiff in sprex:
    print spiff



def spiffup(dbrex):
  spfup = {}; spfdep = {}
  v6count = 0; v4count = 0; alls = 0; allalls = 0
  for reck in dbrex:
    spfr = reck[11]
    if spfr != None:
      try: 
        spfmult = spfr.split('#')
        for spfrec in spfmult:
          meks = spfrec.split(' ')
          for mek in meks:
            if mek.find('ip4') >= 0: v4count += 1
            if mek.find('ip6') >= 0: v6count += 1
            if mek.find('+all') >= 0: alls += 1
            if mek.find('all') >= 0: allalls += 1
          spfup = accumulate(spfup, len(meks))
        spfdep = accumulate(spfdep, len(spfmult))
      except:
        meks = spfr.split(' ')
        if mek.find('ip4') >= 0: v4count += 1
        if mek.find('ip6') >= 0: v6count += 1
        if mek.find('+all') >= 0: alls += 1
        if mek.find('all') >= 0: allalls += 1
        spfup = accumulate(spfup, len(meks))
        spfdep = accumulate(spfdep, 1)

  print "Range of SPF mechanism lengths:"
  for oneup in spfup:
    print "%d = %d" % (oneup, spfup[oneup])
  print "Total unique SPF records: %s" % (sumup(spfup))
  print "Range of SPF record depths:"
  for onedep in spfdep:
    print "%d = %d" % (onedep, spfdep[onedep])
  print "ip6 versus ip4:"
  print "ip6 = %d, ip4 = %d, ratio = %d%%" % (v6count, v4count, (v6count*100/v4count))
  print "Spam Vectors (+all) vs (all): %d / %d = %d" % (alls, allalls, alls*100/allalls)


if __name__ == "__main__":

  allsql = "select * from results;"
  dbhasrex = False; alldbrex = []
  countup = {}; subup = {}; spfup = {}; dmarcup = {}; dkimup = {}
  dkdisp = { '0' : "fail", '1' : "pass", 'False' : "fail", 'Fail' : "fail", 'True' : "pass" }

  try:
    dbn = sys.argv[1]
    argtoo = sys.argv[2]
    (dbhasrex, alldbrex) = squall.extract_all(dbn, allsql)
  except:
    sys.exit("Usage: python dmarcstats.py olddmarc.db|pmarc.db <qualifier>")

  if not dbhasrex:
    sys.exit("No records in %s" % (dbn))

  #sys.argv[2] determines what analysis is to be done:
  if argtoo == "raw":
    for line in alldbrex:
      print line

  elif argtoo == "domain":
    for reck in alldbrex:
      countup = accumulate(countup, reck[5])
    printsorted(countup)
    print "%d unique users." % (len(countup))
    printtld(countup)

  elif argtoo == "subject":
    for reck in alldbrex:
      subup = accumulate(subup, "%s:%s" % (reck[17], reck[9]))
    printsorted(subup)
    print "%d unique subjects." % (len(subup))

  elif argtoo == "spfrec":
    spiffup(alldbrex)

  elif argtoo == "spfrecurse":
    for reck in alldbrex:
      try:
        if reck[11].find('#') > 0:
          cursers = reck[11].split('#')
          print cursers[0]
          for onespf in cursers[1:]:
            print "\t%s" % (onespf)
      except: pass

  elif argtoo == "spfrecord":
    spiffsort(alldbrex)

  elif argtoo == "dkimrec":
    for reck in alldbrex:
      dkimup = accumulate(dkimup, reck[12])
    printsorted(dkimup)
    print "%d unique subjects, %d total subjects." % (len(dkimup), sumup(dkimup))

  elif argtoo == "dmarcrec":
    for reck in alldbrex:
      dmarcup = accumulate(dmarcup, reck[13])
    printsorted(dmarcup)
    print "%d unique subjects, %d total subjects." % (len(dmarcup), sumup(dmarcup))

  elif argtoo == "dkimsig":
    for reck in alldbrex:
      dkimup = accumulate(dkimup, reck[8])
    printsorted(dkimup)
    print "%d DKIM Signature dispositions." % (len(dkimup))

  elif argtoo == "dmarcresult":
    for reck in alldbrex:
      dkimup = accumulate(dmarcup, reck[17])
    printsorted(dmarcup)
    print "%d DMARC dispositions." % (len(dmarcup))

  elif argtoo == "spfresult":
    for reck in alldbrex:
      try: spfup = accumulate(spfup, "%s:%s" % (reck[14], dkdisp[reck[15]]))
      except: print "Bad Key combination: '%s', '%s'" % (reck[14], reck[15])
    printsorted(spfup)
    print "Total: %d" % (sumup(spfup))

  else:
    print "Usage: python dmarcresults.py dbname.db raw|domain|subject|spfrec|dkimrec|dmarcrec|dkimsig|dmarcresult|spfresult"

