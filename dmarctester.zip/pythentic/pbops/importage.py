import sys, os

'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''

def findimports(aline):
  imps = aline.split(" ", 1)
  himps = imps[1].split("#")
  allimps = himps[0].split(",")
  for animp in allimps:

    if animp.find(" ") > 0:
      allpars = animp.split(" ")
      asify = "%s.py" % (allpars[0].strip())
      if os.path.exists(asify):
        print asify
        importer(asify)

    else:
      piify = "%s.py" % (animp.strip())
      if os.path.exists(piify):
        print piify
        importer(piify)


def importer(pyfile):
  for line in open(pyfile):

    if line.startswith("#"): continue

    if line.find("import ") >= 0:
      findimports(line)

if __name__ == "__main__":

  importer(sys.argv[1])


