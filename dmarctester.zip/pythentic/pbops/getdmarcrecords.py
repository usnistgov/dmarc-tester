import sys, os

'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''

#Append a dmarc record if not already there:
def augmentif(uniqrex, candidate):

  for rek in uniqrex:
    if rek == candidate:
      return uniqrex

  uniqrex.append(candidate)
  return uniqrex


#Print the vector:
def printvector(avec):

  for el in avec:
    print el


if __name__ == "__main__":
  uniqs = []

  for line in open('/var/spool/mail/night'):
    if line.find('DMARCrecord=v=') >= 0:
      parts = line.strip().split('DMARCrecord=')
      uniqs = augmentif(uniqs, parts[1])

  uniqs.sort(key=len)
  printvector(uniqs)

