import sys, os

'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''

#Usage: python spfdomains.py <spf args file>
#File Contains: <ipaddr> <name@domain> <helodomain>
#Confirm that the domain in a mailfrom (user@domain) is the
#same as the helo domain. Print the differences.

if __name__ == "__main__":

  for line in open(sys.argv[1]):
    line = line.strip()
    if line == "": continue
    args = line.split(" ")
    (nom, dom) = args[1].split("@")
    if args[2][-1] == ".":
      spfdom = args[2][:-1]
    else:
      spfdom = args[2]
    if not dom == spfdom:
      print line

