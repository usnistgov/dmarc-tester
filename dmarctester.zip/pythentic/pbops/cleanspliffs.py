import sys, os

'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''


def printdict(adict):

  for key in adict:
    tups = adict[key]
    print  "%s %s %s" % (tups[0], tups[1], tups[2])


if __name__ == "__main__":
  uniqs = {}

  for line in open("/tmp/pythentic.rlog"):
    if not line.find("spf args") >= 0: continue
    if line.find("127.0.0.1") > 0: continue
    line = line.strip()
    line = line[25:]
    try:
      sparts = line.split(',')
      if sparts[1].strip() == "": continue
    except:
      os.write(2, "%s\n" % (line))
      continue
    if sparts[0].find("]") > 0:
      sparts[0] = sparts[0].split("]")[0]
    uniqs[sparts[0].strip()] = sparts[0].strip(),sparts[2].strip(),sparts[1].strip()

  printdict(uniqs)

