import cgi, cgitb, os, sys, squall

'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''

if __name__ == "__main__":
  content = "Content-type: text/html\n"
  form = cgi.FieldStorage()
  query = form.getvalue('q')
  addr = form.getvalue('addr')
  adhash = form.getvalue('hash')

  print content
  print "q=%s, addr=%s, hash=%s" % (query, addr, adhash)

