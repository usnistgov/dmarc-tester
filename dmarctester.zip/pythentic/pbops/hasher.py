
import sys, os, hashlib, base64 
psalts = "ps"  # alternates for + and / are (p)lus, (s)lash.
from Crypto.Hash import SHA1
from Crypto.PublicKey import RSA
from Crypto import Random
from Crypto.Signature import PKCS1_v1_5

''' hasher.py '''

'''

    Author: Stephen Nightingale
            High Assurance Domains Project
            U.S. National Institute of Standards and Technology
            night@nist.gov

    Date: November 2012 - August 2016

    Disclaimer:
            This software was developed by an Agency of the United States Government
            and can be used for any purpose free of any copyright or other license.

'''

#Given an address, a private key and an algorithm
#return the hash of the address using the key and the algorithm.

def hash_the_address(addr, priv):

  h = SHA1.new(addr)
  key = RSA.importKey(open(priv).read())
  signer = PKCS1_v1_5.new(key)
  signature = signer.sign(h)
  return base64.b64encode(signature)


def old_hash_the_address(addr, priv):
  digest = hashlib.sha1(addr).digest()
  rsa = m2.RSA.load_key(priv)
  sig = rsa.sign(digest)
  return base64.b64encode(sig, psalts)

def old_digest_the_address(addr, priv, alg):
  digest = hashlib.sha1(addr).digest()
  rsa = m2.RSA.load_key(priv)
  sig = rsa.sign(digest, alg)
  sog = base64.b64encode(sig, psalts)
  return sog

#Given an address, a signature, a public key and an algorithm
#return the value after verifying the decoded signature using the key and algorithm

def verify_the_address(addr, sig, allregs):
  theregs = open(allregs).read()
  regadds = theregs.split('\n')
  for add in regadds:
    bits = add.split("&")
    if addr == bits[0].lower() and sig.find(bits[2]) >= 0:
      return True
  return False

if __name__ == "__main__":
  priv = "../.domainkeys/rsa.private"
  regs = "registered.txt"

  try:
    addr = sys.argv[1]
  except: sys.exit("Usage: python hasher.py <an address>")

  sign = hash_the_address(addr, priv)
  print "Signature: ", sign
  verf = verify_the_address(addr, sign, regs)
  print "Verification: ", verf

